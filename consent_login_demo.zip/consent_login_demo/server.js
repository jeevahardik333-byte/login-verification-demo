const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || "change-this-admin-key";
const DATA_FILE = path.join(__dirname, "submissions.json");
const PUBLIC_DIR = path.join(__dirname, "public");

function readData() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function send(res, status, body, type="application/json; charset=utf-8") {
  res.writeHead(status, {"Content-Type": type, "Cache-Control":"no-store"});
  res.end(type.startsWith("application/json") ? JSON.stringify(body) : body);
}
function safeEqual(a, b) {
  const x = Buffer.from(String(a || ""));
  const y = Buffer.from(String(b || ""));
  return x.length === y.length && require("crypto").timingSafeEqual(x, y);
}
const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (req.method === "POST" && url.pathname === "/api/submit") {
    let raw = "";
    req.on("data", chunk => { raw += chunk; if (raw.length > 5000) req.destroy(); });
    req.on("end", () => {
      try {
        const body = JSON.parse(raw || "{}");
        const userId = String(body.userId || "").trim().slice(0, 100);
        if (!body.consent || !userId) return send(res, 400, {error:"Consent and a demo user ID are required."});
        const entries = readData();
        entries.push({
          id: Date.now().toString(36) + Math.random().toString(36).slice(2,7),
          userId,
          demoResult: "Submitted demo verification",
          consent: true,
          submittedAt: new Date().toISOString()
        });
        fs.writeFileSync(DATA_FILE, JSON.stringify(entries, null, 2));
        send(res, 200, {ok:true, message:"Demo submission received. No password was collected."});
      } catch { send(res, 400, {error:"Invalid submission."}); }
    });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/admin/submissions") {
    const key = req.headers["x-admin-key"] || url.searchParams.get("key");
    if (!safeEqual(key, ADMIN_KEY)) return send(res, 401, {error:"Unauthorized"});
    return send(res, 200, {submissions: readData()});
  }

  if (req.method === "GET" && url.pathname === "/") {
    return send(res, 200, fs.readFileSync(path.join(PUBLIC_DIR, "index.html"), "utf8"), "text/html; charset=utf-8");
  }
  if (req.method === "GET" && url.pathname === "/admin") {
    return send(res, 200, fs.readFileSync(path.join(PUBLIC_DIR, "admin.html"), "utf8"), "text/html; charset=utf-8");
  }
  send(res, 404, {error:"Not found"});
});
server.listen(PORT, () => console.log(`Demo app running on port ${PORT}`));
